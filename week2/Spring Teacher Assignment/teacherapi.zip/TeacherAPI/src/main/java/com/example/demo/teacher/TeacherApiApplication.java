package com.example.demo.teacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherApiApplication.class, args);
	}

}
