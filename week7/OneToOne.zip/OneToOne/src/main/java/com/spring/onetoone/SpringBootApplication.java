package com.spring.onetoone;

public @interface SpringBootApplication {

}
