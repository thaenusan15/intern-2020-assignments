package com.spring.onetoone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.onetoone.entity.Address;
import com.spring.onetoone.repo.AddressRepo;

@Service
public class AddressService {

	@Autowired
	AddressRepo addrepo;

	public List<Address> findAll() {
		return addrepo.findAll();
	}

	public Address addAddress(Address address) {
		return addrepo.save(address);
	}

	
}
