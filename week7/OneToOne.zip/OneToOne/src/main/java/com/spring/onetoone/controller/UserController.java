package com.spring.onetoone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.onetoone.entity.User;
import com.spring.onetoone.service.UserService;

@RestController
public class UserController {

	
	@Autowired
	UserService userservice;
	
	@GetMapping (value = "/user")
	public List<User> getUser() {
		return userservice.findAll();
	}
	@PostMapping (value = "/user")
	public User addUser(@RequestBody User user) {
		return userservice.addUser(user);
	}
}
