package com.spring.onetoone.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.onetoone.entity.Address;

@Repository
public interface AddressRepo extends JpaRepository<Address, Long>{



	
}
