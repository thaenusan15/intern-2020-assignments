package com.spring.onetoone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.onetoone.entity.Address;
import com.spring.onetoone.service.AddressService;

@RestController
public class AddressController {

	
	@Autowired
	AddressService addservice;
	
	@GetMapping (value = "/address")
	public List<Address> getAddress() {
		return addservice.findAll();
	}
	@PostMapping (value = "/address")
	public Address addAddress(@RequestBody Address address) {
		return addservice.addAddress(address);
	}
}
