package com.example.demo.teacher.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.teacher.entity.TeacherEntity;
import com.example.demo.teacher.repository.TeacherRepo;



@Service
public class TeacherService {
	@Autowired
TeacherRepo teacherRepository;
	
	

	public List<TeacherEntity> getTeacher() {
		// TODO Auto-generated method stub
		return teacherRepository.findAll();
	}
	public TeacherEntity addTeacher(TeacherEntity teacher) {
		// TODO Auto-generated method stub
		return teacherRepository.save(teacher);
	}
	
	public TeacherEntity findById(long id) {
		return teacherRepository.findById(id).orElse(null);
	}
	
	public void deleteTeacher(long id) {
		teacherRepository.deleteById(id);
	}
	
	public List<TeacherEntity> searchTeacher(String teacherName, String teacherPhone) {
		//TODO Auto-generated method stub
		 return teacherRepository.searchEntity(teacherName,teacherPhone);
	}
}
