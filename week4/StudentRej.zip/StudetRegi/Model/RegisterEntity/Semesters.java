package RegisterEntity;

import RegisterControl.SemestersControl;

public class Semesters {
	SemestersControl semestersControl=new SemestersControl();
	String semester;
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	

}
