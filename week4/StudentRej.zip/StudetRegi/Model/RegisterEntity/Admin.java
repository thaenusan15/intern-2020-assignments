package RegisterEntity;

import RegisterControl.AdminControl;

public class Admin {
public int Id;

public String Password;
AdminControl adminControl=new AdminControl();

	public int getId() {
		return Id;
	}


	public void setId(int id) {
		Id = id;
	}


	public String getPassword() {
		return Password;
	}


	public void setPassword(String password) {
		Password = password;
	}
    

}
