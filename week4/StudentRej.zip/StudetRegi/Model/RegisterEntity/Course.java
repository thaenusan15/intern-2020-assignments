package RegisterEntity;

import RegisterControl.CourseControl;

public class Course {
	CourseControl courseControl=new CourseControl();
	public int Id;
	public String name;
	public String department;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
}
