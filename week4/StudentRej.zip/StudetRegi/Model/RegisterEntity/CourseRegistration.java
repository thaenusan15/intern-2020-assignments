package RegisterEntity;

import RegisterControl.CourseRegistrationControl;

public class CourseRegistration {
	CourseRegistrationControl courseRegistrationControl=new CourseRegistrationControl();

	    

		

		

}
