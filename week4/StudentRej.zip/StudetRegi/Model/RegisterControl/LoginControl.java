package RegisterControl;
public class LoginControl {

    
    public LoginControl() {
    }

   
      public void isEquals(int Id,String Password) {
        
    }

}