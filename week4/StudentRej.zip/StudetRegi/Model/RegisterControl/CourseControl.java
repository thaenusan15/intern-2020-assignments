package RegisterControl;

public class CourseControl extends CourseRegistrationControl {
public void addCourse() {
	
}
public void deleteCourse() {
	
}
}
