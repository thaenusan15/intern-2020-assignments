package RegisterControl;
public class CourseRegistrationControl {

    public CourseRegistrationControl() {
    }

   

    public void addRegistration() {
    	
        
    }

  
    public void deleteRegistration() {
       
    }
    
    

}