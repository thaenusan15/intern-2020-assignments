package RegisterControl;
public class AdminControl extends LoginControl {

   
    public AdminControl() {
   
    }

   
    
     public void login() {
    	
        
    }


   
    public void Confirm() {
       
    }

    
    public void Define() {
    	
       }

}