package RegisterControl;
public class SemestersControl extends CourseRegistrationControl{

   
    public void chooseSemesterControl(String semester) {
   
		}

}