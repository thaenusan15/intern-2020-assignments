package RegisterControl;

public class StudentControl extends LoginControl{

    public StudentControl() {
    }

   
     public void login() {
    	
        
    }
     
    public void register() {
        
    }

}